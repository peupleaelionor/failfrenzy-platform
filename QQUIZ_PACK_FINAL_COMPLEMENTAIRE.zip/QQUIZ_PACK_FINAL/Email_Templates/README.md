# 📧 QQUIZ PRODIGY - Templates Email

## Vue d'ensemble

Ce dossier contient tous les templates d'emails HTML pour QQUIZ PRODIGY. Tous les templates sont responsive, optimisés pour les clients email (Gmail, Outlook, Apple Mail, etc.) et suivent la charte graphique gaming néon de l'app.

## 📁 Templates disponibles

### 1. **email_verification.html**
- **Usage :** Vérification d'email lors de l'inscription
- **Variables :**
  - `{{VERIFICATION_URL}}` : Lien de vérification unique
- **Expiration :** 24 heures
- **CTA principal :** "VÉRIFIER MON EMAIL"

### 2. **email_password_reset.html**
- **Usage :** Réinitialisation du mot de passe
- **Variables :**
  - `{{RESET_URL}}` : Lien de réinitialisation unique
- **Expiration :** 1 heure
- **CTA principal :** "RÉINITIALISER MON MOT DE PASSE"
- **Sécurité :** Notice de sécurité incluse

### 3. **email_achievement_unlock.html**
- **Usage :** Notification de déblocage d'achievement
- **Variables :**
  - `{{ACHIEVEMENT_NAME}}` : Nom du badge
  - `{{COINS_REWARD}}` : Nombre de pièces gagnées
  - `{{XP_REWARD}}` : Points XP gagnés
  - `{{APP_URL}}` : Lien vers l'app
- **CTA principal :** "VOIR MON PROFIL"

## 🎨 Style & Design

### Palette de couleurs
```css
/* Backgrounds */
--dark-bg: #0F172A;
--dark-card: #1E293B;

/* Primary Colors */
--violet: #8B5CF6;
--cyan: #06B6D4;
--orange: #F97316;
--gold: #FCD34D;

/* Text Colors */
--text-white: #ffffff;
--text-gray: #94A3B8;
--text-muted: #64748B;
```

### Caractéristiques
- ✅ **Responsive** : S'adapte mobile et desktop
- ✅ **Compatible** : Gmail, Outlook, Apple Mail, Yahoo, etc.
- ✅ **Inline CSS** : Tous les styles sont inline pour compatibilité
- ✅ **Dark mode** : Fond sombre gaming
- ✅ **Glassmorphism** : Cartes avec effet verre
- ✅ **Neon accents** : Bordures et ombres néon violet/cyan
- ✅ **Call-to-action** : Boutons orange avec dégradé

## 🔧 Intégration

### Exemple Node.js (Nodemailer)

```javascript
const nodemailer = require('nodemailer');
const fs = require('fs');

// Charger le template
let emailTemplate = fs.readFileSync('./email_verification.html', 'utf8');

// Remplacer les variables
emailTemplate = emailTemplate.replace('{{VERIFICATION_URL}}', verificationUrl);

// Envoyer l'email
const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: { user: 'your-email@gmail.com', pass: 'your-password' }
});

await transporter.sendMail({
  from: '"QQUIZ PRODIGY" <noreply@qquizprodigy.com>',
  to: userEmail,
  subject: 'Vérifie ton email - QQUIZ PRODIGY',
  html: emailTemplate
});
```

### Exemple Python (Flask-Mail)

```python
from flask_mail import Mail, Message
from flask import render_template_string

# Charger le template
with open('email_verification.html', 'r') as f:
    email_template = f.read()

# Remplacer les variables
email_html = email_template.replace('{{VERIFICATION_URL}}', verification_url)

# Envoyer l'email
msg = Message(
    subject='Vérifie ton email - QQUIZ PRODIGY',
    sender=('QQUIZ PRODIGY', 'noreply@qquizprodigy.com'),
    recipients=[user_email],
    html=email_html
)
mail.send(msg)
```

### Exemple PHP (PHPMailer)

```php
use PHPMailer\PHPMailer\PHPMailer;

$mail = new PHPMailer(true);

// Charger le template
$emailTemplate = file_get_contents('email_verification.html');

// Remplacer les variables
$emailHtml = str_replace('{{VERIFICATION_URL}}', $verificationUrl, $emailTemplate);

// Configuration SMTP
$mail->isSMTP();
$mail->Host = 'smtp.gmail.com';
$mail->SMTPAuth = true;
$mail->Username = 'your-email@gmail.com';
$mail->Password = 'your-password';
$mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
$mail->Port = 587;

// Envoyer l'email
$mail->setFrom('noreply@qquizprodigy.com', 'QQUIZ PRODIGY');
$mail->addAddress($userEmail);
$mail->Subject = 'Vérifie ton email - QQUIZ PRODIGY';
$mail->isHTML(true);
$mail->Body = $emailHtml;

$mail->send();
```

## 🧪 Test des emails

### Outils recommandés

1. **Litmus** (https://litmus.com/)
   - Test sur 90+ clients email
   - Preview mobile et desktop

2. **Email on Acid** (https://www.emailonacid.com/)
   - Test de rendu email
   - Validation HTML/CSS

3. **Mailtrap** (https://mailtrap.io/)
   - Email testing pour dev
   - Pas d'envoi réel

### Test local rapide

```bash
# Ouvrir dans navigateur pour preview
open email_verification.html

# Test d'envoi avec MailHog (Docker)
docker run -d -p 1025:1025 -p 8025:8025 mailhog/mailhog
# Interface web : http://localhost:8025
```

## 📋 Variables disponibles

| Template | Variable | Type | Exemple |
|----------|----------|------|---------|
| Verification | `{{VERIFICATION_URL}}` | String | `https://app.qquiz.com/verify?token=abc123` |
| Password Reset | `{{RESET_URL}}` | String | `https://app.qquiz.com/reset?token=xyz789` |
| Achievement | `{{ACHIEVEMENT_NAME}}` | String | `Champion des 100 Victoires` |
| Achievement | `{{COINS_REWARD}}` | Number | `500` |
| Achievement | `{{XP_REWARD}}` | Number | `1000` |
| Achievement | `{{APP_URL}}` | String | `https://app.qquiz.com/profile` |

## ⚠️ Best Practices

### À faire ✅
- Toujours utiliser inline CSS
- Tester sur Gmail, Outlook, Apple Mail
- Utiliser des tableaux pour la structure (pas de flexbox/grid)
- Préférer des images hébergées (pas base64)
- Garder la largeur max à 600px
- Utiliser des fallback fonts
- Inclure un lien texte en plus du bouton

### À éviter ❌
- Flexbox ou CSS Grid
- JavaScript
- Vidéos ou animations complexes
- Fichiers CSS externes
- Polices web custom sans fallback
- Images trop lourdes (max 200KB par image)

## 🔐 Sécurité

### Tokens de vérification
- Utiliser des tokens cryptographiquement sécurisés (UUID v4 ou JWT)
- Définir une expiration courte (24h pour verification, 1h pour reset)
- Invalider le token après utilisation
- Ne jamais réutiliser les tokens

### Exemple génération token (Node.js)
```javascript
const crypto = require('crypto');
const token = crypto.randomBytes(32).toString('hex');
// Stocker avec expiration en BDD
```

## 📱 Responsive Design

Les templates sont optimisés pour :
- 📧 Desktop : 600px width
- 📱 Mobile : 100% width avec padding adaptatif
- 💻 Tablet : Même comportement que mobile

### Media queries incluses
```css
@media only screen and (max-width: 600px) {
  .container { width: 100% !important; }
  .button { display: block !important; width: 100% !important; }
}
```

## 🎯 Taux d'ouverture & Engagement

### Conseils pour maximiser l'engagement
1. **Subject line** : Court (< 50 caractères), avec emoji
   - ✅ "Vérifie ton email 🎮"
   - ✅ "Nouveau badge débloqué ! 🏆"
   
2. **Preheader text** : Complément au subject (première ligne visible)
   
3. **CTA clair** : Un seul CTA principal, bien visible

4. **Timing** : Envoyer aux heures optimales (10h-14h, 18h-20h)

## 🌐 Traductions

Pour ajouter d'autres langues, dupliquer les templates et remplacer les textes :
- `email_verification_en.html` (anglais)
- `email_verification_es.html` (espagnol)
- `email_verification_de.html` (allemand)

## 📞 Support

Pour toute question sur les templates email :
- 📧 Consulter la documentation complète
- 💬 Vérifier les exemples de code ci-dessus
- 🔧 Tester avec les outils recommandés

---

**Note :** Les templates utilisent des tableaux HTML pour garantir la compatibilité maximale avec tous les clients email. Cette approche est standard dans l'industrie malgré son aspect "old school".