# 🎨 QQUIZ PRODIGY - Alternative Themes

## Vue d'ensemble

Ce dossier contient des alternatives de thèmes visuels pour QQUIZ PRODIGY, permettant de personnaliser l'expérience utilisateur ou de créer des événements spéciaux saisonniers.

## 📁 Fichiers disponibles

### 1. Dark_vs_Light_Mode_Comparison.png (89.42 KB)
Comparaison côte à côte des modes Dark et Light.

### 2. Alternative_Color_Themes_4.png (151.83 KB)
Showcase de 4 thèmes de couleurs alternatifs :
- **ORIGINAL** : Violet/Cyan/Orange (thème par défaut)
- **OCEAN** : Bleu profond/Aqua/Teal
- **FIRE** : Rouge/Orange/Jaune
- **FOREST** : Vert/Lime/Émeraude

## 🎨 Thèmes disponibles

### ORIGINAL (Default) 🟣
```css
--primary: #8B5CF6;      /* Violet néon */
--secondary: #06B6D4;    /* Cyan */
--accent: #F97316;       /* Orange gaming */
--gold: #FCD34D;         /* Gold premium */
--bg-dark: #0F172A;      /* Dark background */
--bg-card: #1E293B;      /* Card background */
```

**Usage :** Thème par défaut de l'app. Gaming, esports, compétitif.

---

### LIGHT MODE ☀️
```css
--bg: #F8FAFC;           /* Light background */
--bg-card: #FFFFFF;      /* Card white */
--bg-gradient: #E2E8F0;  /* Gradient end */
--primary: #8B5CF6;      /* Violet (même) */
--secondary: #06B6D4;    /* Cyan (même) */
--accent: #F97316;       /* Orange (même) */
--text: #0F172A;         /* Dark text */
--text-muted: #64748B;   /* Muted gray */
```

**Changements clés :**
- Fonds clairs au lieu de sombres
- Texte sombre sur fond clair
- Ombres légères (shadows) au lieu de glows néon
- Bordures subtiles au lieu de néons

**Usage :** Option pour utilisateurs préférant les interfaces claires. Meilleure lisibilité en plein jour.

**Activation :**
```javascript
const [theme, setTheme] = useState('dark');

const toggleTheme = () => {
  setTheme(theme === 'dark' ? 'light' : 'dark');
  AsyncStorage.setItem('theme', theme === 'dark' ? 'light' : 'dark');
};
```

---

### OCEAN THEME 🌊
```css
--primary: #1E40AF;      /* Deep blue */
--secondary: #06B6D4;    /* Aqua */
--accent: #14B8A6;       /* Teal */
--gold: #3B82F6;         /* Bright blue */
--bg-dark: #0C1B2E;      /* Deep ocean */
--bg-card: #1E3A5F;      /* Ocean card */
```

**Ambiance :** Océan, calme, profondeur, mystère.  
**Usage :** Thème spécial "Catégorie Océan/Géographie" ou événement saisonnier été.

---

### FIRE THEME 🔥
```css
--primary: #DC2626;      /* Red */
--secondary: #F97316;    /* Orange */
--accent: #FBBF24;       /* Yellow */
--gold: #FDE047;         /* Bright yellow */
--bg-dark: #1C0F0A;      /* Dark ember */
--bg-card: #3A1F1A;      /* Ember card */
```

**Ambiance :** Intensité, chaleur, compétition extrême.  
**Usage :** Mode "Duel" ou événements spéciaux haute intensité, challenges difficiles.

---

### FOREST THEME 🌲
```css
--primary: #059669;      /* Emerald green */
--secondary: #84CC16;    /* Lime */
--accent: #10B981;       /* Green */
--gold: #22C55E;         /* Bright green */
--bg-dark: #0A1F0F;      /* Deep forest */
--bg-card: #1A3A25;      /* Forest card */
```

**Ambiance :** Nature, croissance, zen, équilibre.  
**Usage :** Thème "Relax Mode" ou catégorie Nature/Biologie/Écologie.

---

## 🔧 Implémentation

### React Native / React

```javascript
// themes.js
export const themes = {
  original: {
    primary: '#8B5CF6',
    secondary: '#06B6D4',
    accent: '#F97316',
    gold: '#FCD34D',
    bgDark: '#0F172A',
    bgCard: '#1E293B',
    text: '#FFFFFF',
    textMuted: '#94A3B8'
  },
  light: {
    primary: '#8B5CF6',
    secondary: '#06B6D4',
    accent: '#F97316',
    gold: '#F59E0B',
    bgDark: '#F8FAFC',
    bgCard: '#FFFFFF',
    text: '#0F172A',
    textMuted: '#64748B'
  },
  ocean: {
    primary: '#1E40AF',
    secondary: '#06B6D4',
    accent: '#14B8A6',
    gold: '#3B82F6',
    bgDark: '#0C1B2E',
    bgCard: '#1E3A5F',
    text: '#FFFFFF',
    textMuted: '#94A3B8'
  },
  fire: {
    primary: '#DC2626',
    secondary: '#F97316',
    accent: '#FBBF24',
    gold: '#FDE047',
    bgDark: '#1C0F0A',
    bgCard: '#3A1F1A',
    text: '#FFFFFF',
    textMuted: '#FCA5A5'
  },
  forest: {
    primary: '#059669',
    secondary: '#84CC16',
    accent: '#10B981',
    gold: '#22C55E',
    bgDark: '#0A1F0F',
    bgCard: '#1A3A25',
    text: '#FFFFFF',
    textMuted: '#86EFAC'
  }
};

// ThemeContext.js
import React, { createContext, useState, useContext } from 'react';
import { themes } from './themes';

const ThemeContext = createContext();

export const ThemeProvider = ({ children }) => {
  const [currentTheme, setCurrentTheme] = useState('original');
  
  const theme = themes[currentTheme];
  
  const changeTheme = (themeName) => {
    if (themes[themeName]) {
      setCurrentTheme(themeName);
      AsyncStorage.setItem('selectedTheme', themeName);
    }
  };
  
  return (
    <ThemeContext.Provider value={{ theme, currentTheme, changeTheme }}>
      {children}
    </ThemeContext.Provider>
  );
};

export const useTheme = () => useContext(ThemeContext);

// Usage dans un composant
import { useTheme } from './ThemeContext';

function QuizCard() {
  const { theme } = useTheme();
  
  return (
    <View style={{
      backgroundColor: theme.bgCard,
      borderColor: theme.primary,
      borderWidth: 2,
      borderRadius: 16,
      padding: 20
    }}>
      <Text style={{ color: theme.text }}>
        Question ici
      </Text>
    </View>
  );
}
```

### CSS Variables (Web)

```css
/* styles/themes.css */
:root[data-theme="original"] {
  --primary: #8B5CF6;
  --secondary: #06B6D4;
  --accent: #F97316;
  --gold: #FCD34D;
  --bg-dark: #0F172A;
  --bg-card: #1E293B;
  --text: #FFFFFF;
  --text-muted: #94A3B8;
}

:root[data-theme="light"] {
  --primary: #8B5CF6;
  --secondary: #06B6D4;
  --accent: #F97316;
  --gold: #F59E0B;
  --bg-dark: #F8FAFC;
  --bg-card: #FFFFFF;
  --text: #0F172A;
  --text-muted: #64748B;
}

:root[data-theme="ocean"] {
  --primary: #1E40AF;
  --secondary: #06B6D4;
  --accent: #14B8A6;
  --gold: #3B82F6;
  --bg-dark: #0C1B2E;
  --bg-card: #1E3A5F;
  --text: #FFFFFF;
  --text-muted: #94A3B8;
}

:root[data-theme="fire"] {
  --primary: #DC2626;
  --secondary: #F97316;
  --accent: #FBBF24;
  --gold: #FDE047;
  --bg-dark: #1C0F0A;
  --bg-card: #3A1F1A;
  --text: #FFFFFF;
  --text-muted: #FCA5A5;
}

:root[data-theme="forest"] {
  --primary: #059669;
  --secondary: #84CC16;
  --accent: #10B981;
  --gold: #22C55E;
  --bg-dark: #0A1F0F;
  --bg-card: #1A3A25;
  --text: #FFFFFF;
  --text-muted: #86EFAC;
}

/* Usage */
.quiz-card {
  background: var(--bg-card);
  color: var(--text);
  border: 2px solid var(--primary);
}

.button-primary {
  background: var(--accent);
  color: var(--text);
}
```

```javascript
// JavaScript pour changer le thème
function changeTheme(themeName) {
  document.documentElement.setAttribute('data-theme', themeName);
  localStorage.setItem('selectedTheme', themeName);
}

// Charger le thème au démarrage
const savedTheme = localStorage.getItem('selectedTheme') || 'original';
changeTheme(savedTheme);
```

## 🎯 Cas d'usage

### 1. Paramètres utilisateur
Permettre aux utilisateurs de choisir leur thème préféré dans les paramètres.

```javascript
<ThemeSelector
  themes={['original', 'light', 'ocean', 'fire', 'forest']}
  currentTheme={currentTheme}
  onSelect={changeTheme}
/>
```

### 2. Thèmes contextuels
Changer automatiquement selon le contexte :
- **Fire** : Mode Duel intense
- **Ocean** : Questions catégorie Géographie
- **Forest** : Mode Relax/Zen

### 3. Événements saisonniers
- **Été** : Ocean theme
- **Automne** : Fire theme
- **Printemps** : Forest theme
- **Hiver** : Original (violet froid)

### 4. Mode jour/nuit automatique
```javascript
useEffect(() => {
  const hour = new Date().getHours();
  if (hour >= 6 && hour < 20) {
    changeTheme('light'); // Jour
  } else {
    changeTheme('original'); // Nuit
  }
}, []);
```

### 5. Récompenses premium
Débloquer des thèmes spéciaux comme récompenses :
- Thème Ocean débloqué à niveau 10
- Thème Fire débloqué après 50 victoires
- Thème Forest débloqué avec badge "Zen Master"

## 🎨 Création de nouveaux thèmes

### Template pour nouveau thème

```javascript
const newTheme = {
  primary: '#??????',    // Couleur principale (boutons, bordures)
  secondary: '#??????',  // Couleur secondaire (accents, highlights)
  accent: '#??????',     // Couleur CTA (Call-to-Action)
  gold: '#??????',       // Couleur premium (badges, récompenses)
  bgDark: '#??????',     // Background principal
  bgCard: '#??????',     // Background cartes/éléments
  text: '#??????',       // Texte principal
  textMuted: '#??????'   // Texte secondaire/discret
};
```

### Règles de design
1. **Contraste :** Minimum WCAG AA (4.5:1) pour texte
2. **Cohérence :** Primary et Secondary doivent s'harmoniser
3. **Hiérarchie :** Accent doit ressortir pour CTAs
4. **Lisibilité :** Tester à petite taille (boutons, badges)
5. **Accessibilité :** Tester avec simulateur daltonisme

## 📱 UI Settings pour sélection thème

```javascript
<ScrollView horizontal>
  {Object.keys(themes).map(themeName => (
    <ThemePreview
      key={themeName}
      name={themeName}
      colors={themes[themeName]}
      selected={currentTheme === themeName}
      onPress={() => changeTheme(themeName)}
    />
  ))}
</ScrollView>
```

---

**Fichiers fournis :**
- ✅ Dark_vs_Light_Mode_Comparison.png (89.42 KB)
- ✅ Alternative_Color_Themes_4.png (151.83 KB)

**Thèmes inclus :** Original (Dark), Light, Ocean, Fire, Forest  
**Format :** PNG reference images + Code CSS/JS ready-to-use