# 📱 QQUIZ PRODIGY - App Store Assets

## iOS App Icons

### Fichier : `iOS_App_Icons_All_Sizes.png`

Ce fichier contient toutes les tailles d'icônes requises pour iOS dans une grille de référence.

### Tailles requises

| Taille | Usage | Devices | Nom Xcode |
|--------|-------|---------|-----------|
| **1024×1024** | App Store | Marketing | `AppIcon-AppStore` |
| **180×180** | App Icon | iPhone @3x | `AppIcon-60@3x` |
| **167×167** | App Icon | iPad Pro | `AppIcon-83.5@2x` |
| **152×152** | App Icon | iPad, iPad mini | `AppIcon-76@2x` |
| **120×120** | App Icon | iPhone @2x | `AppIcon-60@2x` |
| **87×87** | Settings | iPhone @3x | `AppIcon-29@3x` |
| **80×80** | Spotlight | iPhone/iPad @2x | `AppIcon-40@2x` |
| **76×76** | App Icon | iPad @1x | `AppIcon-76` |
| **58×58** | Settings | iPhone/iPad @2x | `AppIcon-29@2x` |
| **40×40** | Spotlight | iPad @1x | `AppIcon-40` |
| **29×29** | Settings | iPad @1x | `AppIcon-29` |

### Génération des assets

```bash
# Utiliser un outil comme ImageMagick pour découper
magick iOS_App_Icons_All_Sizes.png -crop 1024x1024+0+0 AppIcon-1024.png
magick iOS_App_Icons_All_Sizes.png -crop 180x180+0+1024 AppIcon-180.png
# etc.

# Ou utiliser un outil en ligne
# https://appicon.co/
# https://makeappicon.com/
```

### Structure Xcode (Assets.xcassets)

```
Assets.xcassets/
└── AppIcon.appiconset/
    ├── Contents.json
    ├── AppIcon-1024.png          (1024×1024)
    ├── AppIcon-60@3x.png         (180×180)
    ├── AppIcon-83.5@2x.png       (167×167)
    ├── AppIcon-76@2x.png         (152×152)
    ├── AppIcon-60@2x.png         (120×120)
    ├── AppIcon-29@3x.png         (87×87)
    ├── AppIcon-40@2x.png         (80×80)
    ├── AppIcon-76.png            (76×76)
    ├── AppIcon-29@2x.png         (58×58)
    ├── AppIcon-40.png            (40×40)
    └── AppIcon-29.png            (29×29)
```

### Contents.json (Xcode)

```json
{
  "images": [
    {
      "size": "20x20",
      "idiom": "iphone",
      "filename": "AppIcon-40@2x.png",
      "scale": "2x"
    },
    {
      "size": "29x29",
      "idiom": "iphone",
      "filename": "AppIcon-29@2x.png",
      "scale": "2x"
    },
    {
      "size": "40x40",
      "idiom": "iphone",
      "filename": "AppIcon-40@2x.png",
      "scale": "2x"
    },
    {
      "size": "60x60",
      "idiom": "iphone",
      "filename": "AppIcon-60@2x.png",
      "scale": "2x"
    },
    {
      "size": "60x60",
      "idiom": "iphone",
      "filename": "AppIcon-60@3x.png",
      "scale": "3x"
    },
    {
      "size": "1024x1024",
      "idiom": "ios-marketing",
      "filename": "AppIcon-1024.png",
      "scale": "1x"
    }
  ],
  "info": {
    "version": 1,
    "author": "xcode"
  }
}
```

## Android Icons

**Note :** Les icônes Android ont été bloquées par le filtre NSFW. Utilisez l'icône 1024×1024 iOS et redimensionnez-la.

### Tailles requises

| Densité | Taille | Dossier | Usage |
|---------|--------|---------|-------|
| **ldpi** | 36×36 | `mipmap-ldpi/` | Anciennes devices |
| **mdpi** | 48×48 | `mipmap-mdpi/` | Baseline |
| **hdpi** | 72×72 | `mipmap-hdpi/` | HD screens |
| **xhdpi** | 96×96 | `mipmap-xhdpi/` | Extra HD |
| **xxhdpi** | 144×144 | `mipmap-xxhdpi/` | Full HD |
| **xxxhdpi** | 192×192 | `mipmap-xxxhdpi/` | 4K screens |
| **Play Store** | 512×512 | N/A | Google Play |

### Génération depuis l'icône iOS

```bash
# Depuis l'icône 1024×1024
magick AppIcon-1024.png -resize 512x512 play-store-icon.png
magick AppIcon-1024.png -resize 192x192 ic_launcher_xxxhdpi.png
magick AppIcon-1024.png -resize 144x144 ic_launcher_xxhdpi.png
magick AppIcon-1024.png -resize 96x96 ic_launcher_xhdpi.png
magick AppIcon-1024.png -resize 72x72 ic_launcher_hdpi.png
magick AppIcon-1024.png -resize 48x48 ic_launcher_mdpi.png
magick AppIcon-1024.png -resize 36x36 ic_launcher_ldpi.png
```

### Structure Android

```
android/app/src/main/res/
├── mipmap-ldpi/
│   └── ic_launcher.png          (36×36)
├── mipmap-mdpi/
│   └── ic_launcher.png          (48×48)
├── mipmap-hdpi/
│   └── ic_launcher.png          (72×72)
├── mipmap-xhdpi/
│   └── ic_launcher.png          (96×96)
├── mipmap-xxhdpi/
│   └── ic_launcher.png          (144×144)
└── mipmap-xxxhdpi/
    └── ic_launcher.png          (192×192)
```

### Adaptive Icons (Android 8.0+)

Créer également des adaptive icons avec foreground et background séparés.

```xml
<!-- res/mipmap-anydpi-v26/ic_launcher.xml -->
<?xml version="1.0" encoding="utf-8"?>
<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">
    <background android:drawable="@color/ic_launcher_background"/>
    <foreground android:drawable="@mipmap/ic_launcher_foreground"/>
</adaptive-icon>
```

## 🛠️ Outils recommandés

### Générateurs d'icônes
- **App Icon Generator** : https://appicon.co/
- **MakeAppIcon** : https://makeappicon.com/
- **Icon Kitchen** : https://icon.kitchen/
- **Ape Tools** : https://apetools.webprofusion.com/app/

### Vérification
- **iOS :** Xcode Asset Catalog Validator
- **Android :** Android Studio Resource Manager

## ✅ Checklist avant soumission

### iOS App Store
- [ ] Icône 1024×1024 sans transparence
- [ ] Icône 1024×1024 sans coins arrondis (Apple les applique)
- [ ] Toutes les tailles requises dans Assets.xcassets
- [ ] Pas d'alpha channel sur l'icône 1024×1024
- [ ] Icône lisible à petite taille (29×29)

### Google Play Store
- [ ] Icône 512×512 au format PNG
- [ ] Icône 512×512 avec transparence optionnelle
- [ ] Tous les mipmaps générés
- [ ] Adaptive icon (foreground + background)
- [ ] Round icon variant pour appareils compatibles

## 🎨 Guidelines

### Apple
- Coins arrondis appliqués automatiquement (ne pas les ajouter)
- Pas d'alpha/transparence
- Lisible à toutes les tailles
- Design cohérent avec brand

### Google
- Peut avoir transparence
- Adaptive icon recommandé (Android 8.0+)
- Safe zone : 66dp dans un cercle de 108dp pour adaptive icons
- Tester avec différents launchers

## 📸 Screenshots App Store (bonus)

### iOS
- **iPhone 6.7"** : 1290×2796 (iPhone 14 Pro Max, 15 Pro Max)
- **iPhone 6.5"** : 1284×2778 (iPhone 14 Plus, 15 Plus)
- **iPhone 5.5"** : 1242×2208 (iPhone 8 Plus)
- **iPad Pro 12.9"** : 2048×2732

### Android
- **Phone** : 1080×1920 minimum
- **7" Tablet** : 1200×1920
- **10" Tablet** : 1600×2560

---

**Fichiers fournis :**
- ✅ iOS_App_Icons_All_Sizes.png (175 KB)
- ⚠️ Android icons : À générer depuis iOS 1024×1024

**Formats :** PNG avec fond opaque (iOS) ou transparent (Android)  
**Optimisation :** Utiliser ImageOptim ou TinyPNG avant upload