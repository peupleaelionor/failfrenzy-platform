# 🌐 QQUIZ PRODIGY - Web Assets

## Vue d'ensemble

Assets web essentiels pour intégration sur site web, SEO, et partage sur réseaux sociaux.

## 📁 Fichiers disponibles

### 1. Favicons_All_Sizes.png (122 KB)
Grid de référence contenant toutes les tailles de favicon nécessaires.

### 2. OpenGraph_Social_Preview.png (178 KB)
Image de prévisualisation pour réseaux sociaux (1200×630px).

### 3. Email_Header_Banner.png (65 KB)
Bannière pour headers d'emails (600×200px).

---

## 🔖 Favicons

### Tailles requises

| Taille | Usage | Nom fichier |
|--------|-------|-------------|
| **512×512** | PWA high-res | `favicon-512.png` |
| **192×192** | Android home screen | `favicon-192.png` |
| **180×180** | Apple touch icon | `apple-touch-icon.png` |
| **32×32** | Desktop browsers | `favicon-32.png` |
| **16×16** | Browser tab | `favicon-16.png` |

### Génération des favicons

```bash
# Utiliser ImageMagick pour créer toutes les tailles
magick Favicons_All_Sizes.png -crop 512x512+0+0 favicon-512.png
magick Favicons_All_Sizes.png -crop 192x192+512+0 favicon-192.png
magick Favicons_All_Sizes.png -crop 180x180+704+0 favicon-180.png
magick Favicons_All_Sizes.png -crop 32x32+884+0 favicon-32.png
magick Favicons_All_Sizes.png -crop 16x16+916+0 favicon-16.png

# Créer le .ico (multi-résolution)
magick favicon-16.png favicon-32.png favicon.ico
```

### HTML Integration

```html
<!DOCTYPE html>
<html lang="fr">
<head>
  <!-- Favicon standard -->
  <link rel="icon" type="image/png" sizes="32x32" href="/favicon-32.png">
  <link rel="icon" type="image/png" sizes="16x16" href="/favicon-16.png">
  <link rel="shortcut icon" href="/favicon.ico">
  
  <!-- Apple Touch Icon -->
  <link rel="apple-touch-icon" sizes="180x180" href="/apple-touch-icon.png">
  
  <!-- Android Chrome -->
  <link rel="icon" type="image/png" sizes="192x192" href="/favicon-192.png">
  <link rel="icon" type="image/png" sizes="512x512" href="/favicon-512.png">
  
  <!-- Web App Manifest -->
  <link rel="manifest" href="/manifest.json">
</head>
</html>
```

### Web App Manifest (manifest.json)

```json
{
  "name": "QQUIZ PRODIGY",
  "short_name": "QQUIZ",
  "description": "Le quiz gaming ultime - Défie tes amis en temps réel !",
  "start_url": "/",
  "display": "standalone",
  "background_color": "#0F172A",
  "theme_color": "#8B5CF6",
  "orientation": "portrait",
  "icons": [
    {
      "src": "/favicon-192.png",
      "sizes": "192x192",
      "type": "image/png",
      "purpose": "any maskable"
    },
    {
      "src": "/favicon-512.png",
      "sizes": "512x512",
      "type": "image/png",
      "purpose": "any maskable"
    }
  ]
}
```

---

## 📱 Open Graph / Social Preview

### Description
Image optimisée pour prévisualisation sur réseaux sociaux :
- **Taille :** 1200×630px (ratio 1.91:1)
- **Format :** PNG (ou JPG)
- **Poids :** 178 KB (< 1 MB recommandé)

### Plateformes supportées
- Facebook
- Twitter (X)
- LinkedIn
- WhatsApp
- Telegram
- Discord

### Meta Tags HTML

```html
<!DOCTYPE html>
<html lang="fr">
<head>
  <!-- Open Graph (Facebook, WhatsApp, LinkedIn) -->
  <meta property="og:title" content="QQUIZ PRODIGY - Le Quiz Gaming Ultime">
  <meta property="og:description" content="Défie tes amis en temps réel sur 20+ catégories ! Rejoins les champions.">
  <meta property="og:image" content="https://qquizprodigy.com/og-image.png">
  <meta property="og:image:width" content="1200">
  <meta property="og:image:height" content="630">
  <meta property="og:url" content="https://qquizprodigy.com">
  <meta property="og:type" content="website">
  <meta property="og:site_name" content="QQUIZ PRODIGY">
  <meta property="og:locale" content="fr_FR">
  
  <!-- Twitter Card -->
  <meta name="twitter:card" content="summary_large_image">
  <meta name="twitter:title" content="QQUIZ PRODIGY - Le Quiz Gaming Ultime">
  <meta name="twitter:description" content="Défie tes amis en temps réel sur 20+ catégories ! Rejoins les champions.">
  <meta name="twitter:image" content="https://qquizprodigy.com/og-image.png">
  <meta name="twitter:site" content="@qquizprodigy">
  <meta name="twitter:creator" content="@qquizprodigy">
  
  <!-- WhatsApp / Telegram (utilise OG) -->
  <!-- Discord (utilise OG + Twitter) -->
</head>
</html>
```

### Test des previews

**Outils de test :**
- **Facebook :** https://developers.facebook.com/tools/debug/
- **Twitter :** https://cards-dev.twitter.com/validator
- **LinkedIn :** https://www.linkedin.com/post-inspector/
- **WhatsApp :** Envoyer le lien dans un chat test
- **Discord :** Coller le lien dans un channel test

### Recommandations
- **Texte lisible** même en petite taille
- **Logo bien visible**
- **Tagline clair**
- **Ratio 1.91:1** (1200×630) OBLIGATOIRE
- **Poids < 1 MB** (idéal < 300 KB)
- **Format PNG ou JPG** (PNG préféré)
- **Pas d'animations** (image statique)

---

## 📧 Email Header Banner

### Description
Bannière optimisée pour headers d'emails HTML :
- **Taille :** 600×200px
- **Format :** PNG
- **Poids :** 65 KB (léger pour emails)

### Usage dans templates email

Déjà intégré dans les templates fournis (`/Email_Templates/`), mais peut être utilisé séparément :

```html
<!-- Version en ligne (CDN/hébergement) -->
<table role="presentation" width="600">
  <tr>
    <td>
      <img 
        src="https://cdn.qquizprodigy.com/email-header.png" 
        alt="QQUIZ PRODIGY"
        width="600"
        height="200"
        style="display: block; width: 100%; max-width: 600px;"
      />
    </td>
  </tr>
</table>

<!-- Version base64 inline (si hébergement impossible) -->
<img 
  src="data:image/png;base64,iVBORw0KG..." 
  alt="QQUIZ PRODIGY"
  width="600"
  height="200"
/>
```

### Optimisation pour emails
- **Dimensions fixes** (600px standard)
- **Poids optimisé** (< 100 KB)
- **Alt text** toujours présent
- **Inline styles** (pas de CSS externe)
- **Hébergement stable** (CDN ou serveur fiable)

---

## 🚀 Optimisation & Performance

### Compression d'images

```bash
# Avec ImageOptim (Mac)
imageoptim favicon-*.png og-image.png

# Avec TinyPNG (API)
curl --request POST \
  --url https://api.tinify.com/shrink \
  --user api:YOUR_API_KEY \
  --data-binary @og-image.png

# Avec cwebp (WebP)
cwebp -q 85 og-image.png -o og-image.webp
```

### Formats modernes

```html
<!-- Servir WebP avec fallback PNG -->
<picture>
  <source srcset="/og-image.webp" type="image/webp">
  <img src="/og-image.png" alt="QQUIZ PRODIGY">
</picture>
```

### CDN Configuration

```nginx
# Nginx config pour cache long
location ~* \.(png|jpg|ico|webp)$ {
  expires 1y;
  add_header Cache-Control "public, immutable";
}
```

---

## 📋 Checklist déploiement

### Favicons
- [ ] Tous les favicons générés (16, 32, 180, 192, 512)
- [ ] favicon.ico créé (multi-résolution)
- [ ] manifest.json configuré
- [ ] Fichiers uploadés à la racine du site
- [ ] HTML head tags ajoutés
- [ ] Test sur différents navigateurs

### Open Graph
- [ ] Image 1200×630px exactement
- [ ] Poids < 1 MB (idéal < 300 KB)
- [ ] Image hébergée sur CDN/serveur stable
- [ ] Meta tags OG ajoutés
- [ ] Meta tags Twitter ajoutés
- [ ] Testé sur Facebook Debugger
- [ ] Testé sur Twitter Card Validator
- [ ] Testé sur WhatsApp/Discord

### Email Banner
- [ ] Image 600×200px
- [ ] Poids optimisé (< 100 KB)
- [ ] Hébergée sur CDN fiable
- [ ] Alt text présent
- [ ] Testé dans templates email
- [ ] Rendu vérifié Gmail/Outlook/Apple Mail

---

## 🔗 URLs de référence

### Outils de génération
- **Favicon Generator** : https://realfavicongenerator.net/
- **Open Graph Preview** : https://www.opengraph.xyz/
- **Image Optimization** : https://tinypng.com/

### Documentation
- **Open Graph Protocol** : https://ogp.me/
- **Twitter Cards** : https://developer.twitter.com/en/docs/twitter-for-websites/cards
- **Web App Manifest** : https://web.dev/add-manifest/

---

**Fichiers fournis :**
- ✅ Favicons_All_Sizes.png (122 KB) - 5 tailles de favicon
- ✅ OpenGraph_Social_Preview.png (178 KB) - 1200×630px
- ✅ Email_Header_Banner.png (65 KB) - 600×200px

**Formats :** PNG optimisés pour web  
**Compatibilité :** Tous navigateurs modernes + emails HTML