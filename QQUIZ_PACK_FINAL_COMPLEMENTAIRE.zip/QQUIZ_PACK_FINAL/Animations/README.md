# 🎬 QQUIZ PRODIGY - Animation Frames

## Vue d'ensemble

Ce dossier contient des frames d'animation qui peuvent être utilisés pour créer des animations Lottie, des sprite sheets, ou servir de référence pour des animations programmatiques.

## 📁 Fichiers disponibles

### 1. Loading_Animation_8_Frames.png (142 KB)
**8 frames** d'animation de loading circulaire avec logo QQUIZ au centre.

### 2. Transition_Animation_6_Frames.png (167 KB)
**6 frames** d'une transition néon entre deux écrans.

---

## 🔄 Loading Animation

### Description
Animation de spinner circulaire avec :
- Logo QQUIZ fixe au centre
- Anneau néon violet/cyan qui tourne
- Particules qui suivent la rotation
- 8 frames pour rotation complète (360°)

### Frames
- **Frame 1 :** 0° (position initiale)
- **Frame 2 :** 45°
- **Frame 3 :** 90°
- **Frame 4 :** 135°
- **Frame 5 :** 180°
- **Frame 6 :** 225°
- **Frame 7 :** 270°
- **Frame 8 :** 315°

### Usage

#### CSS Animation (Web)

```css
@keyframes spin-loading {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}

.loading-spinner {
  width: 80px;
  height: 80px;
  background: url('/assets/loading-ring.png');
  animation: spin-loading 1s linear infinite;
}

.loading-logo {
  width: 40px;
  height: 40px;
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
}
```

#### React Native (Animated)

```javascript
import { Animated } from 'react-native';

const spinValue = new Animated.Value(0);

Animated.loop(
  Animated.timing(spinValue, {
    toValue: 1,
    duration: 1000,
    useNativeDriver: true
  })
).start();

const spin = spinValue.interpolate({
  inputRange: [0, 1],
  outputRange: ['0deg', '360deg']
});

return (
  <View style={styles.container}>
    <Animated.Image
      source={require('./loading-ring.png')}
      style={[styles.ring, { transform: [{ rotate: spin }] }]}
    />
    <Image
      source={require('./logo-center.png')}
      style={styles.logo}
    />
  </View>
);
```

#### Sprite Sheet (Unity/Godot)

```csharp
// Unity C# - Sprite animation
public class LoadingSpinner : MonoBehaviour
{
    public Sprite[] frames;
    private SpriteRenderer spriteRenderer;
    private int currentFrame = 0;
    public float frameRate = 12f; // 8 frames = ~0.67s for full rotation
    
    void Start()
    {
        spriteRenderer = GetComponent<SpriteRenderer>();
        InvokeRepeating("NextFrame", 0f, 1f / frameRate);
    }
    
    void NextFrame()
    {
        currentFrame = (currentFrame + 1) % frames.Length;
        spriteRenderer.sprite = frames[currentFrame];
    }
}
```

---

## 🌊 Transition Animation

### Description
Transition néon "wipe" d'un écran à l'autre avec :
- Vague néon violet qui traverse l'écran
- Particules et glow effects
- 6 frames pour transition complète
- Effet glassmorphism

### Frames
- **Frame 1 :** Écran A visible (0% transition)
- **Frame 2 :** Vague néon démarre (20%)
- **Frame 3 :** Vague à mi-parcours avec particules (40%)
- **Frame 4 :** Vague continue (60%)
- **Frame 5 :** Vague révèle écran B (80%)
- **Frame 6 :** Écran B totalement visible (100%)

### Usage

#### React Navigation (Custom Transition)

```javascript
import { Animated } from 'react-native';

const TransitionWipe = ({ progress, children }) => {
  const translateX = progress.interpolate({
    inputRange: [0, 1],
    outputRange: [-300, 300]
  });
  
  return (
    <View style={styles.container}>
      {children}
      <Animated.View
        style={[
          styles.wipeOverlay,
          {
            transform: [{ translateX }],
            opacity: progress.interpolate({
              inputRange: [0, 0.5, 1],
              outputRange: [0, 1, 0]
            })
          }
        ]}
      >
        {/* Gradient néon violet */}
        <LinearGradient
          colors={['transparent', '#8B5CF6', 'transparent']}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 0 }}
          style={styles.gradient}
        />
      </Animated.View>
    </View>
  );
};

// Utilisation avec React Navigation
const screenOptions = {
  cardStyleInterpolator: TransitionWipe,
  transitionSpec: {
    open: { animation: 'timing', config: { duration: 400 } },
    close: { animation: 'timing', config: { duration: 400 } }
  }
};
```

#### CSS Keyframe Animation (Web)

```css
@keyframes wipe-transition {
  0% {
    clip-path: inset(0 100% 0 0);
    filter: brightness(1);
  }
  50% {
    clip-path: inset(0 0 0 0);
    filter: brightness(1.5) saturate(1.5);
  }
  100% {
    clip-path: inset(0 0 0 100%);
    filter: brightness(1);
  }
}

.screen-transition {
  animation: wipe-transition 0.6s cubic-bezier(0.4, 0, 0.2, 1);
}

/* Effet néon overlay */
.wipe-overlay {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: linear-gradient(
    90deg,
    transparent 0%,
    rgba(139, 92, 246, 0.8) 50%,
    transparent 100%
  );
  pointer-events: none;
  animation: wipe-slide 0.6s ease-in-out;
}

@keyframes wipe-slide {
  0% { transform: translateX(-100%); }
  100% { transform: translateX(100%); }
}
```

#### Lottie Animation (After Effects export)

Pour créer une animation Lottie à partir des frames :

1. **Importer les frames dans After Effects**
2. **Créer une composition** (1920×1080 ou 1080×1920 mobile)
3. **Ajouter les frames** en séquence
4. **Ajouter des effets** :
   - Glow
   - Particules (CC Particle World)
   - Flou gaussien
5. **Exporter avec Bodymovin** :
   ```json
   {
     "v": "5.7.4",
     "fr": 30,
     "ip": 0,
     "op": 60,
     "w": 1080,
     "h": 1920
   }
   ```

---

## 🎨 Création d'animations Lottie

### Outils recommandés

1. **Adobe After Effects + Bodymovin**
   - Plugin : [Bodymovin](https://aescripts.com/bodymovin/)
   - Export JSON pour Lottie

2. **LottieFiles Creator**
   - https://lottiefiles.com/creator
   - Éditeur en ligne

3. **Haiku Animator**
   - https://www.haikuforteams.com/
   - Export Lottie natif

### Template Lottie (JSON)

```json
{
  "v": "5.7.4",
  "fr": 30,
  "ip": 0,
  "op": 240,
  "w": 400,
  "h": 400,
  "nm": "QQUIZ Loading",
  "ddd": 0,
  "assets": [],
  "layers": [
    {
      "ddd": 0,
      "ind": 1,
      "ty": 4,
      "nm": "Ring",
      "sr": 1,
      "ks": {
        "o": { "a": 0, "k": 100 },
        "r": { 
          "a": 1,
          "k": [
            { "t": 0, "s": [0], "e": [360] },
            { "t": 240, "s": [360] }
          ]
        }
      }
    }
  ]
}
```

---

## 💻 Intégration Lottie

### React Native (lottie-react-native)

```javascript
import LottieView from 'lottie-react-native';

function LoadingScreen() {
  return (
    <View style={styles.container}>
      <LottieView
        source={require('./animations/loading.json')}
        autoPlay
        loop
        style={{ width: 200, height: 200 }}
      />
      <Text>Chargement...</Text>
    </View>
  );
}
```

### React Web (lottie-react)

```javascript
import Lottie from 'lottie-react';
import loadingAnimation from './animations/loading.json';

function Loading() {
  return (
    <div className="loading-container">
      <Lottie
        animationData={loadingAnimation}
        loop
        autoplay
        style={{ width: 200, height: 200 }}
      />
    </div>
  );
}
```

### Flutter (lottie)

```dart
import 'package:lottie/lottie.dart';

class LoadingScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Lottie.asset(
        'assets/animations/loading.json',
        width: 200,
        height: 200,
        repeat: true,
      ),
    );
  }
}
```

---

## 📐 Spécifications techniques

### Loading Animation
- **Frames :** 8
- **Loop :** Oui (infini)
- **Durée recommandée :** 1 seconde par rotation
- **FPS :** 8 FPS (1 frame = 125ms)
- **Taille :** 200×200px recommandé

### Transition Animation
- **Frames :** 6
- **Loop :** Non (one-shot)
- **Durée recommandée :** 400-600ms
- **FPS :** 10 FPS (1 frame = 100ms)
- **Easing :** Cubic-bezier(0.4, 0, 0.2, 1)

---

## 🎯 Use Cases

### Loading States
- **App Launch** : Splash screen avec loading
- **Data Fetch** : Pendant chargement API
- **Image Load** : Placeholder pendant chargement image
- **Processing** : Pendant calcul/traitement

### Transitions
- **Navigation** : Entre écrans
- **Modal** : Ouverture/fermeture
- **Tab Switch** : Changement d'onglet
- **Level Complete** : Transition fin de niveau

---

## 🔧 Performance Tips

### Optimisation
- Utiliser `useNativeDriver: true` (React Native)
- Précharger les animations au démarrage
- Réduire la complexité si lag
- Utiliser des SVG au lieu de PNG si possible

### Fallback
```javascript
// Si Lottie échoue, fallback simple
const [lottieError, setLottieError] = useState(false);

{lottieError ? (
  <ActivityIndicator size="large" color="#8B5CF6" />
) : (
  <LottieView
    source={loadingAnimation}
    onAnimationFailure={() => setLottieError(true)}
  />
)}
```

---

**Fichiers fournis :**
- ✅ Loading_Animation_8_Frames.png (142 KB) - 8 frames rotation
- ✅ Transition_Animation_6_Frames.png (167 KB) - 6 frames wipe

**Format :** PNG sprite sheets  
**Usage :** CSS animation, React Native Animated, Lottie reference, Unity/Godot sprite sheets